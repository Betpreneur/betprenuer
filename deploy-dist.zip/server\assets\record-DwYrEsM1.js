import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState, useEffect, useMemo } from "react";
import { a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function StatCard({
  label,
  value
}) {
  return /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-4", children: [
    /* @__PURE__ */ jsx("div", { className: "text-[24px] font-bold text-win-green", children: value }),
    /* @__PURE__ */ jsx("div", { className: "text-[12px] text-muted-foreground mt-0.5 uppercase tracking-wide", children: label })
  ] });
}
function TierBadge({
  tier
}) {
  const colors = {
    banker: "bg-brand-green text-primary-foreground",
    value_gem: "bg-teal-600 text-white",
    wild_card: "bg-purple-600 text-white"
  };
  return /* @__PURE__ */ jsx("span", { className: `text-[11px] font-medium px-2 py-0.5 rounded ${colors[tier] || "bg-gray-600 text-white"}`, children: tier?.replace("_", " ") || "" });
}
function ResultBadge({
  status
}) {
  const styles = {
    won: "text-win-green",
    loss: "text-danger-red",
    void: "text-muted-foreground",
    pending: "text-amber-500"
  };
  return /* @__PURE__ */ jsx("span", { className: `text-[12px] font-medium ${styles[status] || "text-muted-foreground"}`, children: status?.toUpperCase() || "" });
}
function RecordPage() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [resultFilter, setResultFilter] = useState("all");
  const [page, setPage] = useState(1);
  const PER_PAGE = 20;
  const load = () => {
    setLoading(true);
    setError(false);
    api.getRecord().then(setData).catch(() => setError(true)).finally(() => setLoading(false));
  };
  useEffect(load, []);
  const filtered = useMemo(() => {
    if (!data?.picks) return [];
    return data.picks.filter((p) => {
      if (resultFilter !== "all" && p.status !== resultFilter) return false;
      return true;
    });
  }, [data, resultFilter]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const visible = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const stats = data?.summary;
  const hasPicks = data && data.picks && data.picks.length > 0;
  if (error) {
    return /* @__PURE__ */ jsxs("div", { className: "text-center py-16", children: [
      /* @__PURE__ */ jsx("p", { className: "text-body-text", children: "Unable to load record." }),
      /* @__PURE__ */ jsx("button", { onClick: load, className: "mt-4 px-4 py-2 bg-brand-green text-primary-foreground rounded-md", children: "Tap to retry" })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { children: "Track record" }),
      /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-1", children: "All picks posted before kick-off. Results auto-settled." })
    ] }),
    loading ? /* @__PURE__ */ jsx("div", { className: "space-y-4", children: /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 gap-3", children: [0, 1, 2].map((i) => /* @__PURE__ */ jsx("div", { className: "h-20 bg-card border border-brand-border rounded-lg animate-pulse" }, i)) }) }) : !hasPicks ? /* @__PURE__ */ jsxs("div", { className: "text-center py-12 bg-card border border-brand-border rounded-lg", children: [
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground", children: "Record building � picks will appear here soon." }),
      /* @__PURE__ */ jsx(Link, { to: "/signup", className: "mt-4 inline-block text-brand-green underline", children: "Sign up to get started ?" })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-3", children: [
        /* @__PURE__ */ jsx(StatCard, { label: "Hit rate", value: stats ? `${stats.hit_rate.toFixed(1)}%` : "�" }),
        /* @__PURE__ */ jsx(StatCard, { label: "ROI flat", value: stats ? `${stats.roi_flat >= 0 ? "+" : ""}${stats.roi_flat.toFixed(1)}%` : "�" }),
        /* @__PURE__ */ jsx(StatCard, { label: "Picks logged", value: stats ? String(stats.picks_logged) : "�" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: ["all", "won", "loss", "void", "pending"].map((r) => /* @__PURE__ */ jsxs("button", { onClick: () => {
        setResultFilter(r);
        setPage(1);
      }, className: `px-3 py-2 rounded-md text-[13px] border ${resultFilter === r ? "bg-brand-green text-primary-foreground border-brand-green" : "bg-card border-brand-border text-body-text"}`, children: [
        r === "all" ? "All" : r[0].toUpperCase() + r.slice(1),
        r !== "all" && stats && /* @__PURE__ */ jsxs("span", { className: "ml-1.5 opacity-70", children: [
          "(",
          r === "won" ? stats.wins : r === "loss" ? stats.losses : r === "void" ? stats.voids : stats.pending,
          ")"
        ] })
      ] }, r)) }),
      /* @__PURE__ */ jsx("div", { className: "bg-card border border-brand-border rounded-lg overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-[13px]", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-subtle-bg text-muted-foreground text-[11px] uppercase", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "text-left px-3 py-2 font-medium", children: "Date" }),
          /* @__PURE__ */ jsx("th", { className: "text-left px-3 py-2 font-medium", children: "Match" }),
          /* @__PURE__ */ jsx("th", { className: "text-left px-3 py-2 font-medium", children: "Market" }),
          /* @__PURE__ */ jsx("th", { className: "text-left px-3 py-2 font-medium", children: "Tier" }),
          /* @__PURE__ */ jsx("th", { className: "text-right px-3 py-2 font-medium", children: "Odds" }),
          /* @__PURE__ */ jsx("th", { className: "text-right px-3 py-2 font-medium", children: "Result" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: visible.map((pick) => /* @__PURE__ */ jsxs("tr", { className: "border-t border-brand-border", children: [
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 whitespace-nowrap text-muted-foreground", children: pick.match_date ? new Date(pick.match_date).toLocaleDateString() : "�" }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsx(Link, { to: `/match/${pick.id}`, className: "hover:text-brand-green", children: pick.fixture }) }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2", children: pick.market }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsx(TierBadge, { tier: pick.tier }) }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 text-right", children: pick.odds ? Number(pick.odds).toFixed(2) : "–" }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 text-right", children: /* @__PURE__ */ jsx(ResultBadge, { status: pick.status }) })
        ] }, pick.id)) })
      ] }) }),
      totalPages > 1 && /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-[13px]", children: [
        /* @__PURE__ */ jsx("button", { disabled: page === 1, onClick: () => setPage((p) => Math.max(1, p - 1)), className: "px-3 py-2 rounded-md border border-brand-border bg-card disabled:opacity-50", children: "Previous" }),
        /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
          "Page ",
          page,
          " of ",
          totalPages
        ] }),
        /* @__PURE__ */ jsx("button", { disabled: page === totalPages, onClick: () => setPage((p) => Math.min(totalPages, p + 1)), className: "px-3 py-2 rounded-md border border-brand-border bg-card disabled:opacity-50", children: "Next" })
      ] })
    ] })
  ] });
}
export {
  RecordPage as component
};
