import { jsx, jsxs } from "react/jsx-runtime";
import { Navigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { u as useAuth, a as api, t as todayLagos, f as formatKickoff } from "./router-CR4jZhbd.js";
import { TrendingUp, Calendar, Activity, ChevronRight, CheckCircle2, Circle } from "lucide-react";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
const HIGH_THRESHOLD = 70;
const LOW_THRESHOLD = 50;
const THRESHOLD = 65;
function ConfidenceBar({
  confidence,
  cleared
}) {
  let barColor = "bg-muted";
  let textColor = "text-muted-foreground";
  let glow = "";
  if (confidence >= HIGH_THRESHOLD) {
    barColor = "bg-green-500";
    textColor = "text-green-400";
    glow = "shadow-[0_0_8px_rgba(34,197,94,0.4)]";
  } else if (confidence >= THRESHOLD) {
    barColor = "bg-brand-green";
    textColor = "text-brand-green";
  } else if (confidence >= LOW_THRESHOLD) {
    barColor = "bg-amber-500";
    textColor = "text-amber-400";
  } else {
    barColor = "bg-red-500/60";
    textColor = "text-red-400/70";
  }
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-[100px] md:min-w-[140px]", children: [
    /* @__PURE__ */ jsx("div", { className: "flex-1 h-1.5 md:h-2 bg-[#1a1a1a] rounded-full overflow-hidden", children: /* @__PURE__ */ jsx("div", { className: `h-full ${barColor} rounded-full transition-all duration-500 ${glow}`, style: {
      width: `${confidence}%`
    } }) }),
    /* @__PURE__ */ jsxs("span", { className: `text-[10px] md:text-[11px] font-semibold ${textColor} w-8 md:w-10 text-right`, children: [
      confidence,
      "%"
    ] })
  ] });
}
function GameCard({
  game,
  isLast
}) {
  const marketRows = [];
  for (let i = 0; i < game.markets.length; i += 2) {
    marketRows.push(game.markets.slice(i, i + 2));
  }
  const leagueColors = {
    "Premier League": "#37003c",
    "La Liga": "#ffce00",
    "Liga MX": "#00ff87",
    "Ligue 1": "#091f3c",
    "Serie A": "#024494",
    "Bundesliga": "#d20515"
  };
  const leagueColor = leagueColors[game.league] || "#22c55e";
  return /* @__PURE__ */ jsxs("div", { className: `group bg-[#0f0f0f] border border-[#1a1a1a] rounded-xl overflow-hidden hover:border-brand-green/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(34,197,94,0.1)] ${!isLast ? "mb-3 md:mb-4" : ""}`, children: [
    /* @__PURE__ */ jsxs("div", { className: "px-3 md:px-6 py-3 md:py-4 border-b border-[#1a1a1a] flex items-center justify-between", style: {
      background: `linear-gradient(90deg, ${leagueColor}15 0%, transparent 100%)`
    }, children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 md:gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "px-2 md:px-3 py-0.5 md:py-1 rounded-full text-[9px] md:text-[11px] font-semibold uppercase tracking-wider", style: {
          backgroundColor: `${leagueColor}25`,
          color: leagueColor
        }, children: [
          /* @__PURE__ */ jsx("span", { className: "hidden md:inline", children: game.league }),
          /* @__PURE__ */ jsx("span", { className: "md:hidden", children: game.league.split(" ")[0] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h3", { className: "text-[14px] md:text-[17px] font-semibold text-white", children: game.match }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] md:text-[12px] text-muted-foreground", children: formatKickoff(game.kickoff_wat) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Link, { to: "/match/$id", params: {
        id: game.id
      }, className: "opacity-0 group-hover:opacity-100 transition-opacity text-brand-green hover:underline flex items-center gap-1 text-[11px] md:text-[12px]", children: [
        /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "View picks" }),
        " ",
        /* @__PURE__ */ jsx(ChevronRight, { className: "w-3 h-3" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "p-3 md:p-5 bg-[#0a0a0a]/50", children: /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-x-4 md:gap-x-8 gap-y-2 md:gap-y-3", children: marketRows.map((row, rowIdx) => /* @__PURE__ */ jsx("div", { className: "contents", children: row.map((m) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 md:gap-3 py-1", children: [
      m.cleared ? /* @__PURE__ */ jsx(CheckCircle2, { className: "w-3 h-3 md:w-4 md:h-4 text-brand-green flex-shrink-0" }) : /* @__PURE__ */ jsx(Circle, { className: "w-3 h-3 md:w-4 md:h-4 text-[#333] flex-shrink-0" }),
      /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsx("div", { className: "text-[11px] md:text-[12px] text-muted-foreground truncate", children: m.market_label }),
        m.odds && /* @__PURE__ */ jsx("div", { className: "text-[10px] md:text-[11px] text-amber-500", children: Number(m.odds).toFixed(2) })
      ] }),
      /* @__PURE__ */ jsx(ConfidenceBar, { confidence: m.confidence, cleared: m.cleared })
    ] }, m.market_id)) }, rowIdx)) }) })
  ] });
}
function DashboardPage() {
  const {
    isAuthed,
    loading
  } = useAuth();
  const [data, setData] = useState(null);
  const [loadingPicks, setLoadingPicks] = useState(true);
  const [error, setError] = useState(false);
  useEffect(() => {
    if (!isAuthed) return;
    setLoadingPicks(true);
    api.getTodayPicks().then(setData).catch(() => setError(true)).finally(() => setLoadingPicks(false));
  }, [isAuthed]);
  if (loading) return null;
  if (!isAuthed) return /* @__PURE__ */ jsx(Navigate, { to: "/record" });
  const games = data?.fixtures?.map((fg) => ({
    id: String(fg.match_id),
    match: fg.fixture,
    kickoff_wat: fg.kickoff,
    league: fg.league,
    markets: fg.picks.map((p) => ({
      market_id: String(p.id),
      market_label: p.market,
      confidence: p.confidence,
      cleared: p.status !== "pending",
      odds: p.odds
    }))
  })) || [];
  if (loading) return null;
  if (!isAuthed) return /* @__PURE__ */ jsx(Navigate, { to: "/record" });
  const totalMarkets = games.reduce((sum, g) => sum + g.markets.length, 0);
  const clearedCount = games.reduce((sum, g) => sum + g.markets.filter((m) => m.cleared).length, 0);
  const highConfCount = games.reduce((sum, g) => sum + g.markets.filter((m) => m.confidence >= HIGH_THRESHOLD).length, 0);
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-[#050505] text-white", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-br from-brand-green/5 via-transparent to-amber-500/5" }),
      /* @__PURE__ */ jsx("div", { className: "absolute top-0 left-1/4 w-96 h-96 bg-brand-green/10 rounded-full blur-[100px]" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-0 right-1/4 w-64 h-64 bg-amber-500/10 rounded-full blur-[80px]" }),
      /* @__PURE__ */ jsxs("div", { className: "relative max-w-6xl mx-auto px-4 md:px-6 py-6 md:py-10", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 md:mb-8", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 mb-2", children: [
              /* @__PURE__ */ jsx(TrendingUp, { className: "w-5 h-5 md:w-6 md:h-6 text-brand-green" }),
              /* @__PURE__ */ jsx("h1", { className: "text-xl md:text-2xl font-bold bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent", children: "FULL MARKET SCORECARD" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-muted-foreground text-[12px] md:text-[14px]", children: "Every fixture analysed today with confidence across all markets" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-muted-foreground text-[11px] md:text-[13px]", children: [
            /* @__PURE__ */ jsx(Calendar, { className: "w-3 h-3 md:w-4 md:h-4" }),
            /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: todayLagos() }),
            /* @__PURE__ */ jsx("span", { className: "sm:hidden", children: todayLagos().split(" ").slice(0, 3).join(" ") })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 mb-6 md:mb-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "bg-[#111] border border-[#222] rounded-lg md:rounded-xl p-3 md:p-5", children: [
            /* @__PURE__ */ jsx("div", { className: "text-2xl md:text-3xl font-bold text-white mb-1", children: games.length }),
            /* @__PURE__ */ jsx("div", { className: "text-[10px] md:text-[12px] text-muted-foreground uppercase tracking-wide", children: "Fixtures" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-[#111] border border-[#222] rounded-lg md:rounded-xl p-3 md:p-5", children: [
            /* @__PURE__ */ jsx("div", { className: "text-2xl md:text-3xl font-bold text-brand-green mb-1", children: totalMarkets }),
            /* @__PURE__ */ jsx("div", { className: "text-[10px] md:text-[12px] text-muted-foreground uppercase tracking-wide", children: "Markets" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-[#111] border border-[#222] rounded-lg md:rounded-xl p-3 md:p-5", children: [
            /* @__PURE__ */ jsx("div", { className: "text-2xl md:text-3xl font-bold text-green-400 mb-1", children: highConfCount }),
            /* @__PURE__ */ jsx("div", { className: "text-[10px] md:text-[12px] text-muted-foreground uppercase tracking-wide", children: "70%+" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "bg-[#111] border border-[#222] rounded-lg md:rounded-xl p-3 md:p-5", children: [
            /* @__PURE__ */ jsx("div", { className: "text-2xl md:text-3xl font-bold text-amber-400 mb-1", children: clearedCount }),
            /* @__PURE__ */ jsx("div", { className: "text-[10px] md:text-[12px] text-muted-foreground uppercase tracking-wide", children: "65%+" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-[#111] border border-[#222] rounded-lg md:rounded-xl p-3 md:p-4 flex flex-col md:flex-row md:items-center gap-3", children: [
          /* @__PURE__ */ jsx(Activity, { className: "w-4 h-4 md:w-5 md:h-5 text-brand-green flex-shrink-0" }),
          /* @__PURE__ */ jsxs("p", { className: "text-[11px] md:text-[13px] text-muted-foreground leading-relaxed", children: [
            /* @__PURE__ */ jsx("span", { className: "text-brand-green font-medium", children: "Green" }),
            " = cleared threshold (65%).",
            /* @__PURE__ */ jsx("span", { className: "text-green-400 font-medium ml-1 md:ml-2", children: "Glow" }),
            " = 70%+ conf.",
            /* @__PURE__ */ jsx("span", { className: "text-red-400/70 font-medium ml-1 md:ml-2", children: "Red" }),
            " = below 50%."
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "max-w-6xl mx-auto px-3 md:px-6 pb-12 md:pb-16", children: /* @__PURE__ */ jsx("div", { className: "space-y-2", children: games.map((game, idx) => /* @__PURE__ */ jsx(GameCard, { game, isLast: idx === games.length - 1 }, game.id)) }) })
  ] });
}
export {
  DashboardPage as component
};
