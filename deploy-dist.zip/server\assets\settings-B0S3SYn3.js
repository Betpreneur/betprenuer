import { jsx, jsxs } from "react/jsx-runtime";
import { useRouter, Navigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { u as useAuth, a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function SettingsPage() {
  const {
    user,
    isAuthed,
    loading,
    refresh,
    logout
  } = useAuth();
  const router = useRouter();
  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => {
    if (user) {
      setName(user.name);
      setWhatsapp(user.whatsapp);
    }
  }, [user]);
  if (loading) return null;
  if (!isAuthed || !user) return /* @__PURE__ */ jsx(Navigate, { to: "/" });
  const dirty = name !== user.name || whatsapp !== user.whatsapp;
  async function save() {
    setError(null);
    setSaving(true);
    try {
      await api.updateMe({
        name,
        whatsapp
      });
      await refresh();
      setToast("Saved.");
      setTimeout(() => setToast(null), 2e3);
    } catch {
      setError("Could not save — tap to retry.");
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "max-w-md mx-auto space-y-5", children: [
    /* @__PURE__ */ jsx("h1", { children: "Settings" }),
    /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-5 space-y-4", children: [
      /* @__PURE__ */ jsx(Field, { label: "Full name", children: /* @__PURE__ */ jsx("input", { value: name, onChange: (e) => setName(e.target.value), className: "ipt", disabled: saving }) }),
      /* @__PURE__ */ jsx(Field, { label: "WhatsApp number", children: /* @__PURE__ */ jsx("input", { value: whatsapp, onChange: (e) => setWhatsapp(e.target.value), className: "ipt", disabled: saving }) }),
      user.username && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Username" }),
        /* @__PURE__ */ jsxs("div", { className: "text-[14px] text-foreground", children: [
          "@",
          user.username
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Email" }),
        /* @__PURE__ */ jsx("div", { className: "text-[14px] text-foreground", children: user.email }),
        /* @__PURE__ */ jsx("p", { className: "text-[12px] text-muted-foreground mt-1", children: "To change your email, contact support." })
      ] }),
      error && /* @__PURE__ */ jsx("div", { className: "bg-danger-bg text-danger-red text-[13px] p-3 rounded-md", children: error }),
      /* @__PURE__ */ jsx("button", { onClick: save, disabled: !dirty || saving, className: "w-full bg-brand-green text-primary-foreground font-medium py-3 rounded-md disabled:opacity-50", children: saving ? "Saving…" : "Save changes" })
    ] }),
    /* @__PURE__ */ jsx("button", { onClick: async () => {
      await logout();
      if (typeof window !== "undefined") {
        window.location.href = "/";
      } else {
        router.navigate({
          to: "/"
        });
      }
    }, className: "w-full border border-brand-border bg-card text-body-text py-3 rounded-md", children: "Log out" }),
    toast && /* @__PURE__ */ jsx("div", { className: "fixed bottom-20 left-1/2 -translate-x-1/2 bg-brand-green text-primary-foreground px-4 py-2 rounded-md text-[13px] shadow", children: toast }),
    /* @__PURE__ */ jsx("style", { children: `
        .ipt { display:block; width:100%; padding:10px 12px; border:1px solid var(--brand-border); border-radius:6px; font-size:15px; background:var(--jet-surface-2); color:var(--pure-white); }
        .ipt:focus { outline:2px solid var(--primary); outline-offset:1px; }
        .ipt:disabled { opacity:0.6; }
      ` })
  ] });
}
function Field({
  label,
  hint,
  children
}) {
  return /* @__PURE__ */ jsxs("label", { className: "block", children: [
    /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: label }),
    children,
    hint && /* @__PURE__ */ jsx("span", { className: "block text-[12px] text-muted-foreground mt-1", children: hint })
  ] });
}
export {
  SettingsPage as component
};
