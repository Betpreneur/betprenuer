import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { u as useAuth, a as api } from "./router-CR4jZhbd.js";
import { ArrowRight, TrendingUp, ShieldCheck, Zap, Trophy, BarChart3 } from "lucide-react";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
const heroStadium = "/assets/hero-stadium-BmLD9uBE.jpg";
const heroAnalytics = "/assets/hero-analytics-D_czaQzi.jpg";
function Landing() {
  const {
    isAuthed,
    loading
  } = useAuth();
  const [stats, setStats] = useState(null);
  useEffect(() => {
    api.getPublicSummary().then(setStats).catch(() => {
    });
  }, []);
  if (loading) return null;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-12 pb-8 px-4 md:px-8 lg:px-12 xl:px-16 2xl:px-24 mx-auto w-full max-w-[1600px]", children: [
    /* @__PURE__ */ jsxs("section", { className: "relative overflow-hidden rounded-2xl border border-brand-border min-h-[560px] md:min-h-[620px]", children: [
      /* @__PURE__ */ jsx("img", { src: heroStadium, alt: "", "aria-hidden": true, width: 1920, height: 1080, className: "absolute inset-0 h-full w-full object-cover" }),
      /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute inset-0 bg-gradient-to-br from-background/95 via-background/75 to-primary/40" }),
      /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute -top-24 -right-24 h-64 w-64 rounded-full bg-primary/40 blur-3xl" }),
      /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute -bottom-32 -left-20 h-72 w-72 rounded-full bg-teal-accent/20 blur-3xl" }),
      /* @__PURE__ */ jsxs("div", { className: "relative px-6 py-12 md:py-16 md:px-10", children: [
        /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 backdrop-blur px-3 py-1 text-[11px] uppercase tracking-wider text-white/90", children: [
          /* @__PURE__ */ jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-win-green animate-pulse" }),
          "Boom · audited track record"
        ] }),
        /* @__PURE__ */ jsxs("h1", { className: "mt-5 text-[34px] md:text-[52px] font-extrabold leading-[1.05] tracking-tight drop-shadow-[0_2px_12px_rgba(0,0,0,0.6)]", children: [
          "Sharper picks. Stronger bankers.",
          /* @__PURE__ */ jsx("br", {}),
          /* @__PURE__ */ jsx("span", { className: "text-primary", children: "Every matchday — Boom!" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-4 max-w-xl text-[15px] md:text-[17px] text-white/90", children: "Betpreneur publishes pre-match picks before kick-off, ranked by a transparent confidence model. No deleted losses, no tipster theatre — just an audited edge you can follow. Free while we're in beta." }),
        /* @__PURE__ */ jsxs("div", { className: "mt-7 flex flex-col sm:flex-row flex-wrap gap-3", children: [
          isAuthed ? /* @__PURE__ */ jsxs(Link, { to: "/home", className: "inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold text-[16px] px-6 py-3.5 rounded-md hover:opacity-90 transition-opacity shadow-lg shadow-primary/30", children: [
            "Go to dashboard ",
            /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })
          ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsxs(Link, { to: "/signup", className: "inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold text-[16px] px-6 py-3.5 rounded-md hover:opacity-90 transition-opacity shadow-lg shadow-primary/30", children: [
              "Sign up — Boom! ",
              /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })
            ] }),
            /* @__PURE__ */ jsx(Link, { to: "/login", className: "inline-flex items-center justify-center gap-2 bg-white text-primary font-bold text-[16px] px-6 py-3.5 rounded-md hover:bg-white/90 transition-colors shadow-lg", children: "Log in" })
          ] }),
          /* @__PURE__ */ jsxs(Link, { to: "/record", className: "inline-flex items-center justify-center gap-2 text-white/90 hover:text-white font-medium px-2 py-3", children: [
            "Check the record ",
            /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-9 grid grid-cols-3 gap-3 max-w-xl", children: [
          /* @__PURE__ */ jsx(StatChip, { label: "Hit rate", value: stats ? `${stats.hit_rate.toFixed(1)}%` : "—", tone: "green" }),
          /* @__PURE__ */ jsx(StatChip, { label: "ROI flat", value: stats ? `+${stats.roi_flat.toFixed(1)}%` : "—", tone: "teal" }),
          /* @__PURE__ */ jsx(StatChip, { label: "Picks logged", value: stats ? String(stats.picks_logged) : "—", tone: "white" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative overflow-hidden rounded-2xl border border-brand-border min-h-[200px] md:min-h-[260px]", children: [
        /* @__PURE__ */ jsx("img", { src: heroAnalytics, alt: "Audited performance trending upward", loading: "lazy", width: 1024, height: 1024, className: "absolute inset-0 h-full w-full object-cover" }),
        /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" }),
        /* @__PURE__ */ jsxs("div", { className: "relative h-full flex flex-col justify-end p-5", children: [
          /* @__PURE__ */ jsx("div", { className: "text-[11px] uppercase tracking-wider text-teal-accent font-semibold", children: "Proof, not promises" }),
          /* @__PURE__ */ jsx("h3", { className: "text-[20px] font-bold mt-1", children: "90 days of audited results" }),
          /* @__PURE__ */ jsx("p", { className: "text-[13px] text-white/80 mt-1", children: "Wins, losses, voids — all logged, all visible." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative overflow-hidden rounded-2xl border border-brand-border min-h-[200px] md:min-h-[260px]", children: [
        /* @__PURE__ */ jsx("img", { src: heroStadium, alt: "Football match under stadium lights", loading: "lazy", width: 1920, height: 1080, className: "absolute inset-0 h-full w-full object-cover" }),
        /* @__PURE__ */ jsx("div", { "aria-hidden": true, className: "absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" }),
        /* @__PURE__ */ jsxs("div", { className: "relative h-full flex flex-col justify-end p-5", children: [
          /* @__PURE__ */ jsx("div", { className: "text-[11px] uppercase tracking-wider text-primary font-semibold", children: "Pre-match · before kick-off" }),
          /* @__PURE__ */ jsx("h3", { className: "text-[20px] font-bold mt-1", children: "Picks posted by 06:30 WAT" }),
          /* @__PURE__ */ jsx("p", { className: "text-[13px] text-white/80 mt-1", children: "Bankers, Value Gems and Wildcards — every matchday." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center max-w-2xl mx-auto", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-[22px] md:text-[26px] font-bold", children: "What you get with Betpreneur" }),
        /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-2", children: "Built for bettors who want a real edge, not noise." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid gap-4 md:grid-cols-3", children: [
        /* @__PURE__ */ jsx(Feature, { icon: /* @__PURE__ */ jsx(TrendingUp, { className: "h-5 w-5" }), title: "Daily edge picks", body: "Bankers, Value Gems and Wildcards posted every morning, ranked by model confidence.", tone: "red" }),
        /* @__PURE__ */ jsx(Feature, { icon: /* @__PURE__ */ jsx(ShieldCheck, { className: "h-5 w-5" }), title: "Fully audited", body: "Every pick is timestamped before kick-off and auto-settled. Losses are never deleted.", tone: "green" }),
        /* @__PURE__ */ jsx(Feature, { icon: /* @__PURE__ */ jsx(Zap, { className: "h-5 w-5" }), title: "Top Pick of the day", body: "The single highest-confidence call, with reasoning, form and risk flags broken down.", tone: "teal" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded-2xl border border-brand-border bg-card p-6 md:p-8", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[20px] md:text-[24px] font-bold mb-5", children: "How it works" }),
      /* @__PURE__ */ jsx("ol", { className: "grid gap-4 md:grid-cols-3", children: [{
        n: 1,
        t: "Sign up",
        b: "Create an account in under a minute."
      }, {
        n: 2,
        t: "Get the picks",
        b: "Open the app each matchday for fresh, ranked picks."
      }, {
        n: 3,
        t: "Track results",
        b: "Every result is auto-settled and added to the public record."
      }].map((s) => /* @__PURE__ */ jsxs("li", { className: "rounded-xl border border-brand-border bg-background/40 p-4", children: [
        /* @__PURE__ */ jsx("div", { className: "h-8 w-8 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center", children: s.n }),
        /* @__PURE__ */ jsx("h3", { className: "mt-3", children: s.t }),
        /* @__PURE__ */ jsx("p", { className: "text-[13px] text-muted-foreground mt-1", children: s.b })
      ] }, s.n)) })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "relative overflow-hidden rounded-2xl border border-primary/40 bg-gradient-to-r from-primary/20 to-card p-8 text-center", children: [
      /* @__PURE__ */ jsx(Trophy, { className: "h-8 w-8 text-primary mx-auto" }),
      /* @__PURE__ */ jsx("h2", { className: "mt-3 text-[22px] md:text-[26px] font-bold", children: "Stop to dey guess. Start to dey cash out." }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-[14px] text-white/80 max-w-md mx-auto", children: "Join Betpreneur, follow audited edge wey serious punters dey ride. Boom!" }),
      /* @__PURE__ */ jsxs("div", { className: "mt-5 flex flex-wrap gap-3 justify-center", children: [
        /* @__PURE__ */ jsxs(Link, { to: "/signup", className: "inline-flex items-center gap-2 bg-primary text-primary-foreground font-semibold px-5 py-3 rounded-md hover:opacity-90", children: [
          "Sign up — Boom! ",
          /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })
        ] }),
        /* @__PURE__ */ jsxs(Link, { to: "/record", className: "inline-flex items-center gap-2 border border-white/30 hover:border-white text-white font-semibold px-5 py-3 rounded-md", children: [
          /* @__PURE__ */ jsx(BarChart3, { className: "h-4 w-4" }),
          " Check record"
        ] })
      ] })
    ] })
  ] });
}
function StatChip({
  label,
  value,
  tone
}) {
  const toneClass = tone === "green" ? "text-win-green" : tone === "teal" ? "text-teal-accent" : "text-white";
  return /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-white/10 bg-black/30 backdrop-blur px-3 py-3", children: [
    /* @__PURE__ */ jsx("div", { className: `text-[20px] md:text-[22px] font-extrabold ${toneClass}`, children: value }),
    /* @__PURE__ */ jsx("div", { className: "text-[10px] uppercase tracking-wider text-white/60 mt-0.5", children: label })
  ] });
}
function Feature({
  icon,
  title,
  body,
  tone
}) {
  const ring = tone === "red" ? "bg-primary/15 text-primary" : tone === "green" ? "bg-win-green-bg/40 text-win-green" : "bg-teal-bg/40 text-teal-accent";
  return /* @__PURE__ */ jsxs("div", { className: "group rounded-xl border border-brand-border bg-card p-5 transition-all hover:-translate-y-0.5 hover:border-primary/40", children: [
    /* @__PURE__ */ jsx("div", { className: `inline-flex h-10 w-10 items-center justify-center rounded-lg ${ring}`, children: icon }),
    /* @__PURE__ */ jsx("h3", { className: "mt-3", children: title }),
    /* @__PURE__ */ jsx("p", { className: "text-[13px] text-muted-foreground mt-1", children: body })
  ] });
}
export {
  Landing as component
};
