import { jsx, jsxs } from "react/jsx-runtime";
import { useRouter, Navigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { u as useAuth, a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function LoginPage() {
  const {
    isAuthed,
    loading,
    refresh
  } = useAuth();
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  if (loading) return null;
  if (isAuthed) return /* @__PURE__ */ jsx(Navigate, { to: "/home" });
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!identifier.trim() || !password) {
      setError("Enter your username/email and password.");
      return;
    }
    setSubmitting(true);
    try {
      await api.login(identifier.trim(), password);
      await refresh();
      router.navigate({
        to: "/home"
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not log you in. Check your details and try again.");
    } finally {
      setSubmitting(false);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "max-w-md mx-auto", children: [
    /* @__PURE__ */ jsx("h1", { children: "Welcome back" }),
    /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-1 mb-6", children: "Log in to see today's picks." }),
    /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-4 bg-card border border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Username or email" }),
        /* @__PURE__ */ jsx("input", { value: identifier, onChange: (e) => setIdentifier(e.target.value), className: "input", autoComplete: "username", required: true })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsxs("span", { className: "flex items-center justify-between text-[13px] font-medium text-foreground mb-1", children: [
          /* @__PURE__ */ jsx("span", { children: "Password" }),
          /* @__PURE__ */ jsx(Link, { to: "/forgot-password", className: "text-info-blue text-[12px] font-normal underline", children: "Forgot password?" })
        ] }),
        /* @__PURE__ */ jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), className: "input", autoComplete: "current-password", required: true })
      ] }),
      error && /* @__PURE__ */ jsx("div", { className: "bg-danger-bg text-danger-red text-[13px] p-3 rounded-md", children: error }),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full bg-primary text-primary-foreground font-semibold py-3 rounded-md disabled:opacity-60", children: submitting ? "Logging in…" : "Log in" }),
      /* @__PURE__ */ jsxs("p", { className: "text-[12px] text-muted-foreground text-center", children: [
        "Don't have an account?",
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/signup", className: "text-info-blue underline", children: "Create an account" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("style", { children: `
        .input { display:block; width:100%; padding:10px 12px; border:1px solid var(--brand-border); border-radius:6px; font-size:15px; background:var(--jet-surface-2); color:var(--pure-white); }
        .input:focus { outline:2px solid var(--primary); outline-offset:1px; }
      ` })
  ] });
}
export {
  LoginPage as component
};
