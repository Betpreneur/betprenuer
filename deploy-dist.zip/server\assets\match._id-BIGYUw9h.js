import { jsx, jsxs } from "react/jsx-runtime";
import { useRouter, Navigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { c as Route, u as useAuth, f as formatKickoff, a as api, l as logoFull } from "./router-CR4jZhbd.js";
import { S as StakeGuide } from "./StakeGuide-CFoD0bBc.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function tierLabel(tier) {
  return tier === "banker" ? "Banker" : tier === "gem" ? "Value Gem" : "Wildcard";
}
const tierBg = {
  banker: "bg-win-green-bg text-win-green",
  gem: "bg-teal-bg text-teal-accent",
  wildcard: "bg-amber-bg text-amber-text"
};
function FormChip({
  r
}) {
  const cls = r === "W" ? "bg-win-green text-background" : r === "L" ? "bg-danger-red text-primary-foreground" : "bg-white/10 text-foreground";
  return /* @__PURE__ */ jsx("span", { className: `inline-flex items-center justify-center w-6 h-6 rounded text-[11px] font-semibold ${cls}`, children: r });
}
function MatchPage() {
  const {
    id
  } = Route.useParams();
  const {
    isAuthed,
    loading
  } = useAuth();
  const router = useRouter();
  const [pick, setPick] = useState(null);
  const [error, setError] = useState(false);
  const [backing, setBacking] = useState(false);
  const [shareMsg, setShareMsg] = useState(null);
  const [preview, setPreview] = useState(null);
  const [generating, setGenerating] = useState(false);
  const load = () => {
    setError(false);
    api.getPick(id).then(setPick).catch(() => setError(true));
  };
  useEffect(() => {
    if (!isAuthed) return;
    load();
  }, [isAuthed, id]);
  if (loading) return null;
  if (!isAuthed) return /* @__PURE__ */ jsx(Navigate, { to: "/record" });
  if (error) {
    return /* @__PURE__ */ jsxs("div", { className: "text-center py-16", children: [
      /* @__PURE__ */ jsx("p", { children: "Could not load this pick." }),
      /* @__PURE__ */ jsx("button", { onClick: () => router.navigate({
        to: "/home"
      }), className: "mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-md", children: "Back to today" })
    ] });
  }
  if (!pick) {
    return /* @__PURE__ */ jsx("div", { className: "h-64 bg-card border border-brand-border rounded-lg animate-pulse" });
  }
  async function handleBacked() {
    if (!pick || pick.user_backed || backing) return;
    setBacking(true);
    try {
      await api.markBacked(pick.id, 0);
      setPick({
        ...pick,
        user_backed: true
      });
    } finally {
      setBacking(false);
    }
  }
  function shareText() {
    if (!pick) return "";
    const signupUrl = "https://betprenuer.lovable.app/signup";
    return [`🎯 Betpreneur pick`, ``, `${pick.match}`, `${pick.market_plain} @ ${Number(pick.odds).toFixed(2)}`, `Confidence: ${pick.confidence.toFixed(1)}% · ${tierLabel(pick.tier)}`, ``, `"${pick.one_line_reason}"`, ``, `Get daily picks → ${signupUrl}`].join("\n");
  }
  async function openPreview() {
    if (!pick || generating) return;
    setGenerating(true);
    try {
      const blob = await renderShareCard(pick);
      if (!blob) throw new Error("no blob");
      const url = URL.createObjectURL(blob);
      const safeName = pick.match.replace(/[^a-z0-9]+/gi, "-").toLowerCase();
      setPreview({
        url,
        blob,
        fileName: `betpreneur-${safeName}.png`
      });
    } catch (e) {
      console.error(e);
      setShareMsg("Could not generate card");
      setTimeout(() => setShareMsg(null), 2500);
    } finally {
      setGenerating(false);
    }
  }
  function closePreview() {
    if (preview) URL.revokeObjectURL(preview.url);
    setPreview(null);
  }
  function downloadFromPreview() {
    if (!preview) return;
    const a = document.createElement("a");
    a.href = preview.url;
    a.download = preview.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setShareMsg("Card downloaded ✓");
    setTimeout(() => setShareMsg(null), 2500);
  }
  async function shareFromPreview() {
    if (!preview) return;
    const file = new File([preview.blob], preview.fileName, {
      type: "image/png"
    });
    const nav = navigator;
    try {
      if (nav.canShare && nav.canShare({
        files: [file]
      })) {
        await nav.share({
          files: [file],
          text: shareText(),
          title: "Betpreneur pick"
        });
        return;
      }
    } catch (e) {
      console.error(e);
    }
    downloadFromPreview();
    const waUrl = `https://wa.me/?text=${encodeURIComponent(shareText())}`;
    window.open(waUrl, "_blank", "noopener,noreferrer");
    setShareMsg("Card saved ✓ Attach it in WhatsApp");
    setTimeout(() => setShareMsg(null), 3500);
  }
  return /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsx(Link, { to: "/home", className: "text-[13px] text-info-blue", children: "← Back to today" }),
    /* @__PURE__ */ jsxs("header", { className: "bg-card border border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h1", { className: "!text-[20px] !leading-tight", children: pick.match }),
          /* @__PURE__ */ jsxs("p", { className: "text-[13px] text-muted-foreground mt-0.5", children: [
            pick.league,
            " · ",
            formatKickoff(pick.kickoff_wat)
          ] })
        ] }),
        /* @__PURE__ */ jsx("span", { className: `text-[12px] px-2 py-1 rounded font-medium ${tierBg[pick.tier]}`, children: tierLabel(pick.tier) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-3 inline-block bg-teal-bg text-teal-accent text-[14px] font-medium px-3 py-1.5 rounded", children: pick.market_plain }),
      /* @__PURE__ */ jsxs("div", { className: "mt-3 text-[13px] text-muted-foreground", children: [
        "Confidence: ",
        /* @__PURE__ */ jsxs("span", { className: "font-medium text-win-green", children: [
          pick.confidence.toFixed(1),
          "%"
        ] }),
        " · ",
        "Odds: ",
        /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: Number(pick.odds).toFixed(2) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "bg-card border border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-3", children: "Recent form" }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsx(Row, { team: pick.match.split(" vs ")[0], form: pick.form_home }),
        /* @__PURE__ */ jsx(Row, { team: pick.match.split(" vs ")[1], form: pick.form_away })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "bg-card border border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-3", children: "Why this pick" }),
      /* @__PURE__ */ jsx("ul", { className: "space-y-2 text-[14px] text-foreground/90", children: pick.goals_profile.map((g, i) => /* @__PURE__ */ jsxs("li", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx("span", { className: "text-win-green mt-0.5", children: "•" }),
        /* @__PURE__ */ jsx("span", { children: g })
      ] }, i)) })
    ] }),
    pick.risk_flag && /* @__PURE__ */ jsxs("div", { className: "bg-amber-bg border border-amber-text/20 rounded-lg p-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[12px] uppercase tracking-wide text-amber-text font-semibold mb-1", children: "Watch out" }),
      /* @__PURE__ */ jsx("p", { className: "text-[14px] text-amber-text", children: pick.risk_flag })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "bg-info-bg border border-info-blue/15 rounded-lg p-5", children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-2 !text-info-blue", children: "Model verdict" }),
      /* @__PURE__ */ jsx("p", { className: "italic text-[14px] text-info-blue", children: pick.model_verdict })
    ] }),
    /* @__PURE__ */ jsx(StakeGuide, { odds: pick.odds, highlight: pick.tier }),
    pick.status === "settled" && pick.result && /* @__PURE__ */ jsxs("div", { className: `rounded-lg p-4 text-center font-medium ${pick.result === "won" ? "bg-win-green-bg text-win-green" : pick.result === "lost" ? "bg-danger-bg text-danger-red" : "bg-white/5 text-foreground"}`, children: [
      pick.result === "won" && "Result: Won ✓",
      pick.result === "lost" && "Result: Lost ✗",
      pick.result === "void" && "Void — stake returned"
    ] }),
    pick.status !== "settled" && /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
      /* @__PURE__ */ jsx("button", { onClick: handleBacked, disabled: pick.user_backed || backing, className: `min-h-[56px] rounded-md font-medium ${pick.user_backed ? "bg-white/10 text-muted-foreground cursor-default" : "bg-win-green text-background hover:opacity-90"}`, children: pick.user_backed ? "Backed ✓" : backing ? "Saving…" : "I backed this" }),
      /* @__PURE__ */ jsxs("button", { onClick: openPreview, disabled: generating, className: "min-h-[56px] rounded-md font-semibold bg-[#25D366] text-background hover:opacity-90 inline-flex items-center justify-center gap-2", "aria-label": "Share on WhatsApp", children: [
        /* @__PURE__ */ jsx("svg", { viewBox: "0 0 24 24", className: "h-5 w-5", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M20.52 3.48A11.86 11.86 0 0 0 12.05 0C5.49 0 .15 5.34.15 11.91a11.86 11.86 0 0 0 1.6 5.97L0 24l6.27-1.64a11.93 11.93 0 0 0 5.78 1.47h.01c6.56 0 11.9-5.34 11.9-11.91 0-3.18-1.24-6.17-3.44-8.44ZM12.06 21.8h-.01a9.86 9.86 0 0 1-5.03-1.38l-.36-.21-3.72.97.99-3.62-.23-.37a9.85 9.85 0 0 1-1.51-5.27c0-5.45 4.44-9.89 9.9-9.89 2.64 0 5.13 1.03 7 2.9a9.83 9.83 0 0 1 2.9 7c0 5.46-4.44 9.9-9.93 9.9Zm5.43-7.41c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.18.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.62.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35Z" }) }),
        generating ? "Preparing…" : "Share on WhatsApp"
      ] }),
      /* @__PURE__ */ jsx("button", { onClick: openPreview, disabled: generating, className: "min-h-[56px] rounded-md font-medium border border-primary text-primary bg-card hover:bg-primary/10", "aria-label": "Download share card image", children: generating ? "Preparing…" : "Preview & download" })
    ] }),
    shareMsg && /* @__PURE__ */ jsx("div", { className: "text-center text-[13px] text-muted-foreground", children: shareMsg }),
    preview && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6", role: "dialog", "aria-modal": "true", onClick: closePreview, children: /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-2xl max-w-md w-full max-h-full overflow-y-auto", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-5 py-3 border-b border-brand-border", children: [
        /* @__PURE__ */ jsx("h2", { className: "!text-[16px] !leading-none", children: "Card preview" }),
        /* @__PURE__ */ jsx("button", { onClick: closePreview, className: "text-muted-foreground hover:text-foreground text-[20px] leading-none px-2", "aria-label": "Close preview", children: "×" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "p-4", children: [
        /* @__PURE__ */ jsx("img", { src: preview.url, alt: "Share card preview", className: "w-full h-auto rounded-lg block" }),
        /* @__PURE__ */ jsx("p", { className: "text-[12px] text-muted-foreground text-center mt-3", children: "Sent at 1080×1080 with a signup link to Betpreneur." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 px-4 pb-4", children: [
        /* @__PURE__ */ jsxs("button", { onClick: shareFromPreview, className: "min-h-[52px] rounded-md font-semibold bg-[#25D366] text-background hover:opacity-90 inline-flex items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsx("svg", { viewBox: "0 0 24 24", className: "h-5 w-5", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M20.52 3.48A11.86 11.86 0 0 0 12.05 0C5.49 0 .15 5.34.15 11.91a11.86 11.86 0 0 0 1.6 5.97L0 24l6.27-1.64a11.93 11.93 0 0 0 5.78 1.47h.01c6.56 0 11.9-5.34 11.9-11.91 0-3.18-1.24-6.17-3.44-8.44Z" }) }),
          "Share on WhatsApp"
        ] }),
        /* @__PURE__ */ jsx("button", { onClick: downloadFromPreview, className: "min-h-[52px] rounded-md font-medium border border-primary text-primary bg-card hover:bg-primary/10", children: "Download PNG" })
      ] })
    ] }) })
  ] });
}
async function renderShareCard(pick) {
  const W = 1080;
  const H = 1080;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  const RED = "#E8192C";
  const RED_DEEP = "#7a0a14";
  const WHITE = "#ffffff";
  const MUTED = "rgba(255,255,255,0.62)";
  const FAINT = "rgba(255,255,255,0.10)";
  const PAD = 72;
  ctx.textBaseline = "top";
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#1a0307");
  bg.addColorStop(0.55, "#0d0d0f");
  bg.addColorStop(1, "#000000");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  const glow = ctx.createRadialGradient(180, 160, 40, 180, 160, 760);
  glow.addColorStop(0, "rgba(232,25,44,0.55)");
  glow.addColorStop(1, "rgba(232,25,44,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = "rgba(255,255,255,0.025)";
  ctx.lineWidth = 1;
  for (let i = 0; i < W; i += 40) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, H);
    ctx.stroke();
  }
  try {
    const logo = await loadImage(logoFull);
    const lh = 84;
    const lw = logo.width / logo.height * lh;
    ctx.drawImage(logo, PAD, PAD, lw, lh);
  } catch {
    ctx.fillStyle = WHITE;
    ctx.font = "900 48px Montserrat, sans-serif";
    ctx.fillText("BETPRENEUR", PAD, PAD + 18);
  }
  const tier = tierLabel(pick.tier).toUpperCase();
  ctx.font = "800 22px Montserrat, sans-serif";
  const tw = ctx.measureText(tier).width;
  const pillW = tw + 40;
  const pillH = 48;
  const pillX = W - PAD - pillW;
  const pillY = PAD + (84 - pillH) / 2;
  roundRect(ctx, pillX, pillY, pillW, pillH, 24);
  ctx.fillStyle = RED;
  ctx.fill();
  ctx.fillStyle = WHITE;
  ctx.fillText(tier, pillX + 20, pillY + 14);
  let y = 280;
  ctx.fillStyle = MUTED;
  ctx.font = "700 22px Montserrat, sans-serif";
  ctx.fillText(`${pick.league.toUpperCase()}  ·  ${formatKickoff(pick.kickoff_wat).toUpperCase()}`, PAD, y);
  y += 44;
  ctx.fillStyle = WHITE;
  ctx.font = "900 88px Montserrat, sans-serif";
  y = wrapText(ctx, pick.match, PAD, y, W - PAD * 2, 96);
  y += 18;
  ctx.fillStyle = RED;
  roundRect(ctx, PAD, y, 96, 8, 4);
  ctx.fill();
  y += 48;
  const cardX = PAD;
  const cardY = y;
  const cardW = W - PAD * 2;
  const cardH = 220;
  roundRect(ctx, cardX, cardY, cardW, cardH, 28);
  ctx.fillStyle = "rgba(255,255,255,0.06)";
  ctx.fill();
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.stroke();
  ctx.fillStyle = MUTED;
  ctx.font = "700 18px Montserrat, sans-serif";
  ctx.fillText("THE PICK", cardX + 36, cardY + 32);
  ctx.fillStyle = WHITE;
  ctx.font = "800 42px Montserrat, sans-serif";
  wrapText(ctx, pick.market_plain, cardX + 36, cardY + 64, cardW - 280, 50);
  ctx.fillStyle = MUTED;
  ctx.font = "700 18px Montserrat, sans-serif";
  const oLab = "ODDS";
  const oLabW = ctx.measureText(oLab).width;
  ctx.fillText(oLab, cardX + cardW - 36 - oLabW, cardY + 32);
  ctx.fillStyle = RED;
  ctx.font = "900 76px Montserrat, sans-serif";
  const oVal = Number(pick.odds).toFixed(2);
  const oValW = ctx.measureText(oVal).width;
  ctx.fillText(oVal, cardX + cardW - 36 - oValW, cardY + 60);
  ctx.fillStyle = FAINT;
  ctx.fillRect(cardX + 36, cardY + 160, cardW - 72, 1);
  ctx.fillStyle = MUTED;
  ctx.font = "700 16px Montserrat, sans-serif";
  ctx.fillText("CONFIDENCE", cardX + 36, cardY + 178);
  const conf = Math.max(0, Math.min(100, pick.confidence));
  ctx.fillStyle = WHITE;
  ctx.font = "800 20px Montserrat, sans-serif";
  const cTxt = `${conf.toFixed(1)}%`;
  const cTxtW = ctx.measureText(cTxt).width;
  ctx.fillText(cTxt, cardX + cardW - 36 - cTxtW, cardY + 176);
  const barX = cardX + 200;
  const barY = cardY + 188;
  const barW = cardW - 200 - 36 - cTxtW - 24;
  roundRect(ctx, barX, barY, barW, 6, 3);
  ctx.fillStyle = "rgba(255,255,255,0.12)";
  ctx.fill();
  const fillGrad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
  fillGrad.addColorStop(0, RED_DEEP);
  fillGrad.addColorStop(1, RED);
  roundRect(ctx, barX, barY, barW * conf / 100, 6, 3);
  ctx.fillStyle = fillGrad;
  ctx.fill();
  y = cardY + cardH + 44;
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.font = "italic 28px Georgia, 'Times New Roman', serif";
  wrapText(ctx, `“${pick.one_line_reason}”`, PAD, y, W - PAD * 2, 40);
  ctx.fillStyle = MUTED;
  ctx.font = "700 20px Montserrat, sans-serif";
  ctx.fillText("JOIN FREE — DAILY EDGE PICKS", PAD, H - PAD - 24);
  ctx.fillStyle = WHITE;
  ctx.font = "800 22px Montserrat, sans-serif";
  const url = "betprenuer.lovable.app/signup";
  const uw = ctx.measureText(url).width;
  ctx.fillText(url, W - PAD - uw, H - PAD - 25);
  return await new Promise((resolve) => canvas.toBlob((b) => resolve(b), "image/png"));
}
function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(" ");
  let line = "";
  let curY = y;
  for (const word of words) {
    const test = line ? line + " " + word : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, curY);
      line = word;
      curY += lineHeight;
    } else {
      line = test;
    }
  }
  if (line) {
    ctx.fillText(line, x, curY);
    curY += lineHeight;
  }
  return curY;
}
function Row({
  team,
  form
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
    /* @__PURE__ */ jsx("span", { className: "text-[14px] text-body-text font-medium truncate", children: team }),
    /* @__PURE__ */ jsx("div", { className: "flex gap-1", children: form.map((r, i) => /* @__PURE__ */ jsx(FormChip, { r }, i)) })
  ] });
}
export {
  MatchPage as component
};
