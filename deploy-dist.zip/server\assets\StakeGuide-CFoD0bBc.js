function StakeGuide(_props) {
  return null;
}
export {
  StakeGuide as S
};
