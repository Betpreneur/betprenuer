import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState(null);
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!email.trim()) {
      setError("Enter the email tied to your account.");
      return;
    }
    setSubmitting(true);
    try {
      await api.forgotPassword(email.trim());
      setSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't send a reset link. Try again.");
    } finally {
      setSubmitting(false);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "max-w-md mx-auto", children: [
    /* @__PURE__ */ jsx("h1", { children: "Reset your password" }),
    /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-1 mb-6", children: "Enter your email and we'll send you a link to set a new password." }),
    sent ? /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-5 space-y-4", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-[14px]", children: [
        "If an account exists for ",
        /* @__PURE__ */ jsx("span", { className: "font-medium", children: email }),
        ", a reset link is on its way. Check your inbox (and spam folder)."
      ] }),
      /* @__PURE__ */ jsx(Link, { to: "/reset-password", search: {
        token: void 0,
        user_id: void 0
      }, className: "block text-center w-full bg-primary text-primary-foreground font-semibold py-3 rounded-md", children: "I have my reset code" }),
      /* @__PURE__ */ jsx(Link, { to: "/login", className: "block text-center text-info-blue underline text-[13px]", children: "Back to log in" })
    ] }) : /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-4 bg-card border border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Email address" }),
        /* @__PURE__ */ jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), className: "input", autoComplete: "email", required: true })
      ] }),
      error && /* @__PURE__ */ jsx("div", { className: "bg-danger-bg text-danger-red text-[13px] p-3 rounded-md", children: error }),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full bg-primary text-primary-foreground font-semibold py-3 rounded-md disabled:opacity-60", children: submitting ? "Sending…" : "Send reset link" }),
      /* @__PURE__ */ jsxs("p", { className: "text-[12px] text-muted-foreground text-center", children: [
        "Remembered it?",
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "text-info-blue underline", children: "Back to log in" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("style", { children: `
        .input { display:block; width:100%; padding:10px 12px; border:1px solid var(--brand-border); border-radius:6px; font-size:15px; background:var(--jet-surface-2); color:var(--pure-white); }
        .input:focus { outline:2px solid var(--primary); outline-offset:1px; }
      ` })
  ] });
}
export {
  ForgotPasswordPage as component
};
