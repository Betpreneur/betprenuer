import { jsxs, jsx } from "react/jsx-runtime";
import { useRouter, Link } from "@tanstack/react-router";
import { useState } from "react";
import { R as Route, a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function VerifyEmailPage() {
  const search = Route.useSearch();
  const [email, setEmail] = useState(search.email ?? "");
  const router = useRouter();
  const [code, setCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [resent, setResent] = useState(false);
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!email.trim()) {
      setError("Enter your email address.");
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setError("Enter a valid email address.");
      return;
    }
    if (code.trim().length !== 6) {
      setError("Enter the 6-digit code we sent you.");
      return;
    }
    setSubmitting(true);
    try {
      await api.verifyEmail(email.trim(), code.trim());
      router.navigate({
        to: "/home"
      });
    } catch (e2) {
      setError(e2 instanceof Error ? e2.message : "That code didn't match. Try again.");
    } finally {
      setSubmitting(false);
    }
  }
  async function onResend() {
    setError(null);
    try {
      await api.resendVerification(email.trim());
      setResent(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't resend the code. Try again in a moment.");
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "max-w-md mx-auto", children: [
    /* @__PURE__ */ jsx("h1", { children: "Verify your email" }),
    /* @__PURE__ */ jsxs("p", { className: "text-[14px] text-muted-foreground mt-1 mb-6", children: [
      "We sent a 6-digit verification code to",
      " ",
      /* @__PURE__ */ jsx("span", { className: "text-foreground font-medium", children: email || "your email" }),
      ". Enter it below to activate your account."
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-4 bg-card border border-brand-border rounded-lg p-5", children: [
      !search.email && /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Email address" }),
        /* @__PURE__ */ jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "you@example.com", className: "input", required: true })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Verification code" }),
        /* @__PURE__ */ jsx("input", { value: code, onChange: (e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6)), inputMode: "numeric", autoComplete: "one-time-code", placeholder: "123456", className: "input tracking-[0.4em] text-center text-lg", required: true }),
        /* @__PURE__ */ jsx("span", { className: "block text-[12px] text-muted-foreground mt-1", children: "We sent a 6-digit code to your email." })
      ] }),
      error && /* @__PURE__ */ jsx("div", { className: "bg-danger-bg text-danger-red text-[13px] p-3 rounded-md", children: error }),
      resent && !error && /* @__PURE__ */ jsx("div", { className: "bg-jet-surface-2 text-info-blue text-[13px] p-3 rounded-md border border-brand-border", children: "New code sent. Check your inbox." }),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full bg-primary text-primary-foreground font-semibold py-3 rounded-md disabled:opacity-60", children: submitting ? "Verifying…" : "Verify email" }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-[12px]", children: [
        /* @__PURE__ */ jsx("button", { type: "button", onClick: onResend, className: "text-info-blue underline", children: "Resend code" }),
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "text-muted-foreground underline", children: "Back to log in" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("style", { children: `
        .input { display:block; width:100%; padding:10px 12px; border:1px solid var(--brand-border); border-radius:6px; font-size:15px; background:var(--jet-surface-2); color:var(--pure-white); }
        .input:focus { outline:2px solid var(--primary); outline-offset:1px; }
      ` })
  ] });
}
export {
  VerifyEmailPage as component
};
