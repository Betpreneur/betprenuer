import { jsxs, jsx } from "react/jsx-runtime";
import { useRouter, Link } from "@tanstack/react-router";
import { useState } from "react";
import { b as Route, a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function ResetPasswordPage() {
  const {
    token,
    user_id
  } = Route.useSearch();
  const router = useRouter();
  const [tokenInput, setTokenInput] = useState(token ?? "");
  const [userIdInput, setUserIdInput] = useState(user_id ?? "");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setSubmitting(true);
    try {
      await api.resetPassword(tokenInput.trim(), password, userIdInput.trim());
      setDone(true);
      setTimeout(() => router.navigate({
        to: "/login"
      }), 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reset password. The link may have expired.");
    } finally {
      setSubmitting(false);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "max-w-md mx-auto", children: [
    /* @__PURE__ */ jsx("h1", { children: "Set a new password" }),
    /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-1 mb-6", children: "Choose a strong password you haven't used before." }),
    /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-4 bg-card border border-brand-border rounded-lg p-5", children: [
      !token && /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Reset code" }),
        /* @__PURE__ */ jsx("input", { value: tokenInput, onChange: (e) => setTokenInput(e.target.value), className: "input", maxLength: 6, required: true })
      ] }),
      !user_id && /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "User ID (from email)" }),
        /* @__PURE__ */ jsx("input", { value: userIdInput, onChange: (e) => setUserIdInput(e.target.value), className: "input", required: true })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "New password" }),
        /* @__PURE__ */ jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), className: "input", autoComplete: "new-password", minLength: 6, required: true })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: "Confirm password" }),
        /* @__PURE__ */ jsx("input", { type: "password", value: confirm, onChange: (e) => setConfirm(e.target.value), className: "input", autoComplete: "new-password", minLength: 6, required: true })
      ] }),
      error && /* @__PURE__ */ jsx("div", { className: "bg-danger-bg text-danger-red text-[13px] p-3 rounded-md", children: error }),
      done && /* @__PURE__ */ jsx("div", { className: "bg-jet-surface-2 text-info-blue text-[13px] p-3 rounded-md border border-brand-border", children: "Password updated. Redirecting to log in…" }),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting || done, className: "w-full bg-primary text-primary-foreground font-semibold py-3 rounded-md disabled:opacity-60", children: submitting ? "Saving…" : "Update password" }),
      /* @__PURE__ */ jsx("p", { className: "text-[12px] text-muted-foreground text-center", children: /* @__PURE__ */ jsx(Link, { to: "/login", className: "text-info-blue underline", children: "Back to log in" }) })
    ] }),
    /* @__PURE__ */ jsx("style", { children: `
        .input { display:block; width:100%; padding:10px 12px; border:1px solid var(--brand-border); border-radius:6px; font-size:15px; background:var(--jet-surface-2); color:var(--pure-white); }
        .input:focus { outline:2px solid var(--primary); outline-offset:1px; }
      ` })
  ] });
}
export {
  ResetPasswordPage as component
};
