import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { u as useAuth, a as api } from "./router-CR4jZhbd.js";
import { S as StakeGuide } from "./StakeGuide-CFoD0bBc.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function TierBadge({
  tier
}) {
  const colors = {
    banker: "bg-brand-green text-primary-foreground",
    value_gem: "bg-teal-600 text-white",
    wild_card: "bg-purple-600 text-white"
  };
  return /* @__PURE__ */ jsx("span", { className: `text-[11px] font-medium px-2 py-0.5 rounded ${colors[tier] || "bg-gray-600 text-white"}`, children: tier?.replace("_", " ") || "" });
}
function TopPickPage() {
  const {
    isAuthed,
    loading: authLoading
  } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    api.getTopPick().then(setData).catch(() => setData(null)).finally(() => setLoading(false));
  }, []);
  if (authLoading || loading || !data) {
    return /* @__PURE__ */ jsx("div", { className: "h-64 bg-card border border-brand-border rounded-lg animate-pulse" });
  }
  const pick = data.pick;
  if (!data.published || !pick) {
    return /* @__PURE__ */ jsx("div", { className: "space-y-5", children: /* @__PURE__ */ jsxs("header", { className: "bg-card border-2 border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[11px] uppercase tracking-wide text-muted-foreground font-semibold mb-1", children: "Top pick" }),
      /* @__PURE__ */ jsx("h1", { className: "!text-[20px] !leading-tight", children: "No pick published yet" }),
      /* @__PURE__ */ jsx("p", { className: "text-[13px] text-muted-foreground mt-1", children: "Check back later for today's top pick." })
    ] }) });
  }
  const showFullDetails = isAuthed;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxs("header", { className: "bg-card border-2 border-brand-green rounded-lg p-5", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[11px] uppercase tracking-wide text-brand-green font-semibold mb-1", children: "Best pick today" }),
      /* @__PURE__ */ jsx("h1", { className: "!text-[20px] !leading-tight", children: pick.fixture }),
      /* @__PURE__ */ jsx("p", { className: "text-[13px] text-muted-foreground mt-0.5", children: pick.league }),
      /* @__PURE__ */ jsxs("div", { className: "mt-3 inline-block bg-brand-green-light text-brand-green text-[14px] font-medium px-3 py-1.5 rounded", children: [
        pick.market,
        " @ ",
        pick.odds ? Number(pick.odds).toFixed(2) : "–"
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-3", children: /* @__PURE__ */ jsx(TierBadge, { tier: pick.tier }) }),
      /* @__PURE__ */ jsxs("div", { className: "mt-3 text-[13px] text-muted-foreground", children: [
        "Confidence: ",
        /* @__PURE__ */ jsxs("span", { className: "font-medium text-brand-green", children: [
          pick.confidence?.toFixed(1),
          "%"
        ] })
      ] })
    ] }),
    showFullDetails ? /* @__PURE__ */ jsxs(Fragment, { children: [
      pick.model_verdict && /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-4", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-[14px] font-medium mb-2", children: "Model Verdict" }),
        /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground", children: pick.model_verdict })
      ] }),
      pick.home_recent_form && pick.home_recent_form.length > 0 && /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-4", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-[14px] font-medium mb-2", children: "Home Form" }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-1", children: pick.home_recent_form.map((r, i) => /* @__PURE__ */ jsx("span", { className: `w-6 h-6 rounded text-[11px] font-medium flex items-center justify-center ${r === "W" ? "bg-win-green text-white" : r === "D" ? "bg-draw-yellow text-black" : "bg-danger-red text-white"}`, children: r }, i)) })
      ] }),
      pick.away_recent_form && pick.away_recent_form.length > 0 && /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-4", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-[14px] font-medium mb-2", children: "Away Form" }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-1", children: pick.away_recent_form.map((r, i) => /* @__PURE__ */ jsx("span", { className: `w-6 h-6 rounded text-[11px] font-medium flex items-center justify-center ${r === "W" ? "bg-win-green text-white" : r === "D" ? "bg-draw-yellow text-black" : "bg-danger-red text-white"}`, children: r }, i)) })
      ] }),
      /* @__PURE__ */ jsx(StakeGuide, { confidence: pick.confidence }),
      pick.status && /* @__PURE__ */ jsx("div", { className: "bg-card border border-brand-border rounded-lg p-4 text-center", children: /* @__PURE__ */ jsx("span", { className: `text-[14px] font-medium ${pick.status === "win" ? "text-win-green" : pick.status === "loss" ? "text-danger-red" : pick.status === "void" ? "text-muted-foreground" : "text-amber-500"}`, children: pick.status === "pending" ? "? Pending" : pick.status === "win" ? "? Won" : pick.status === "loss" ? "? Lost" : "? Voided" }) })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "bg-card border border-brand-border rounded-lg p-6 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "mx-auto w-12 h-12 rounded-full bg-subtle-bg flex items-center justify-center text-brand-green text-xl", children: "??" }),
      /* @__PURE__ */ jsx("h2", { className: "mt-3", children: "Full analysis and stake guide" }),
      /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-1", children: "Sign up free to unlock." }),
      /* @__PURE__ */ jsx(Link, { to: "/signup", className: "mt-4 inline-block w-full bg-brand-green text-primary-foreground font-medium py-3 rounded-md", children: "Sign up � free" })
    ] }),
    /* @__PURE__ */ jsx(Link, { to: "/record", className: "block text-center text-info-blue text-[14px] underline", children: "See our 90-day track record ?" })
  ] });
}
export {
  TopPickPage as component
};
