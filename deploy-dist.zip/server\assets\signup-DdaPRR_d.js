import { jsx, jsxs } from "react/jsx-runtime";
import { useRouter, Navigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { u as useAuth, a as api } from "./router-CR4jZhbd.js";
import "dayjs";
import "dayjs/plugin/utc.js";
import "dayjs/plugin/timezone.js";
import "lucide-react";
function SignupPage() {
  const {
    isAuthed,
    loading,
    refresh
  } = useAuth();
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  if (loading) return null;
  if (isAuthed) return /* @__PURE__ */ jsx(Navigate, { to: "/home" });
  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!username.trim() || !password || !email.trim()) {
      setError("Please fill in all fields.");
      return;
    }
    if (username.trim().length < 3) {
      setError("Username must be at least 3 characters.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    setSubmitting(true);
    try {
      await api.signup({
        username: username.trim(),
        password,
        email: email.trim()
      });
      router.navigate({
        to: "/verify-email",
        search: {
          email: email.trim()
        }
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not complete signup. Try again.");
    } finally {
      setSubmitting(false);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "max-w-md mx-auto", children: [
    /* @__PURE__ */ jsx("h1", { children: "Create your account" }),
    /* @__PURE__ */ jsx("p", { className: "text-[14px] text-muted-foreground mt-1 mb-6", children: "Free while we're in beta. Daily picks posted by 06:30 WAT." }),
    /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-4 bg-card border border-brand-border rounded-lg p-5", children: [
      /* @__PURE__ */ jsx(Field, { label: "Username", hint: "You'll use this to log in. Letters, numbers, and underscores.", children: /* @__PURE__ */ jsx("input", { value: username, onChange: (e) => setUsername(e.target.value), className: "input", autoComplete: "username", minLength: 3, maxLength: 30, required: true }) }),
      /* @__PURE__ */ jsx(Field, { label: "Email address", children: /* @__PURE__ */ jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), className: "input", autoComplete: "email", required: true }) }),
      /* @__PURE__ */ jsx(Field, { label: "Password", hint: "At least 6 characters.", children: /* @__PURE__ */ jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), className: "input", autoComplete: "new-password", minLength: 6, required: true }) }),
      error && /* @__PURE__ */ jsx("div", { className: "bg-danger-bg text-danger-red text-[13px] p-3 rounded-md", children: error }),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full bg-primary text-primary-foreground font-semibold py-3 rounded-md disabled:opacity-60", children: submitting ? "Creating account…" : "Sign up — free" }),
      /* @__PURE__ */ jsxs("p", { className: "text-[12px] text-muted-foreground text-center", children: [
        "Already have an account?",
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "text-info-blue underline", children: "Log in" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("style", { children: `
        .input { display:block; width:100%; padding:10px 12px; border:1px solid var(--brand-border); border-radius:6px; font-size:15px; background:var(--jet-surface-2); color:var(--pure-white); }
        .input:focus { outline:2px solid var(--primary); outline-offset:1px; }
      ` })
  ] });
}
function Field({
  label,
  hint,
  children
}) {
  return /* @__PURE__ */ jsxs("label", { className: "block", children: [
    /* @__PURE__ */ jsx("span", { className: "block text-[13px] font-medium text-foreground mb-1", children: label }),
    children,
    hint && /* @__PURE__ */ jsx("span", { className: "block text-[12px] text-muted-foreground mt-1", children: hint })
  ] });
}
export {
  SignupPage as component
};
