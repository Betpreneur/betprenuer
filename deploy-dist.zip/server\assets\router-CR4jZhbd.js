import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useRouter, Link, createRootRoute, Outlet, HeadContent, Scripts, createFileRoute, lazyRouteComponent, createRouter } from "@tanstack/react-router";
import { useState, useEffect, createContext, useContext } from "react";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc.js";
import timezone from "dayjs/plugin/timezone.js";
import { Home, Trophy, BarChart3, Settings } from "lucide-react";
const __vite_import_meta_env__ = {};
const API_BASE_URL = __vite_import_meta_env__?.VITE_API_BASE_URL ?? "https://backend.betpreneur.ng/api";
const ENDPOINTS = {
  signup: "/auth/signup/",
  login: "/auth/login/",
  logout: "/auth/logout/",
  verifyEmail: "/auth/verify-email/",
  resendVerification: "/auth/resend-verification/",
  forgotPassword: "/auth/forgot-password/",
  resetPassword: "/auth/reset-password/",
  changePassword: "/auth/change-password/",
  refresh: "/auth/token/refresh/",
  me: "/auth/me/",
  // Picks
  algoPicks: "/algo/picks/",
  algoPick: (id) => `/algo/picks/${id}/`,
  algoBackPick: (id) => `/algo/picks/${id}/back/`,
  algoTopPick: "/algo/top-pick/",
  // Public
  algoPublicRecord: "/algo/public/record/",
  algoPublicSummary: "/algo/public/summary/"
};
function apiUrl(path) {
  if (!API_BASE_URL) return path;
  return `${API_BASE_URL.replace(/\/$/, "")}${path.startsWith("/") ? path : `/${path}`}`;
}
const TOKEN_KEY = "terminal.token";
const REFRESH_KEY = "terminal.refresh";
const USER_KEY = "terminal.user";
const session = {
  hasToken() {
    if (typeof window === "undefined") return false;
    return !!localStorage.getItem(TOKEN_KEY);
  },
  getToken() {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(TOKEN_KEY);
  },
  getRefresh() {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(REFRESH_KEY);
  },
  setTokens(access, refresh) {
    if (typeof window === "undefined") return;
    localStorage.setItem(TOKEN_KEY, access);
    if (refresh) localStorage.setItem(REFRESH_KEY, refresh);
  },
  // Back-compat alias
  setToken(t) {
    this.setTokens(t);
  },
  clear() {
    if (typeof window === "undefined") return;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_KEY);
    localStorage.removeItem(USER_KEY);
  }
};
function mapUser(u) {
  return {
    id: String(u.id),
    name: u.username,
    username: u.username,
    email: u.email,
    whatsapp: u.full_whatsapp ?? `${u.whatsapp_country_code ?? ""}${u.whatsapp_number ?? ""}`,
    bankroll: 0,
    created_at: u.date_joined,
    is_email_verified: u.is_email_verified
  };
}
function writeUser(u) {
  if (typeof window === "undefined") return;
  localStorage.setItem(USER_KEY, JSON.stringify(u));
}
function splitWhatsapp(raw) {
  const trimmed = raw.trim().replace(/\s+/g, "");
  const m = trimmed.match(/^(\+\d{1,4})(.*)$/);
  if (m) return { code: m[1].slice(0, 5), number: m[2].replace(/\D/g, "").slice(0, 15) };
  return { code: "+234", number: trimmed.replace(/\D/g, "").slice(0, 15) };
}
function extractError(payload, fallback) {
  if (!payload || typeof payload !== "object") return fallback;
  const obj = payload;
  if (typeof obj.detail === "string") return obj.detail;
  if (typeof obj.message === "string") return obj.message;
  if (typeof obj.error === "string") return obj.error;
  for (const v of Object.values(obj)) {
    if (Array.isArray(v) && typeof v[0] === "string") return v[0];
    if (typeof v === "string") return v;
  }
  return fallback;
}
async function tryRefresh() {
  const refresh = session.getRefresh();
  if (!refresh) return false;
  try {
    const res = await fetch(apiUrl(ENDPOINTS.refresh), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh })
    });
    if (!res.ok) return false;
    const data = await res.json();
    if (!data.access) return false;
    session.setTokens(data.access, data.refresh ?? refresh);
    return true;
  } catch {
    return false;
  }
}
async function request(path, init, retry = true) {
  const token = session.getToken();
  const headers = {
    "Content-Type": "application/json",
    ...token ? { Authorization: `Bearer ${token}` } : {},
    ...init?.headers ?? {}
  };
  const res = await fetch(apiUrl(path), { ...init, headers });
  if (res.status === 401 && retry && session.getRefresh()) {
    const ok = await tryRefresh();
    if (ok) return request(path, init, false);
  }
  if (!res.ok) {
    let payload = null;
    try {
      payload = await res.json();
    } catch {
      try {
        payload = await res.text();
      } catch {
      }
    }
    throw new Error(extractError(payload, `Request failed (${res.status})`));
  }
  if (res.status === 204) return void 0;
  return await res.json();
}
const isoToday = (h, m = 0) => {
  const d = /* @__PURE__ */ new Date();
  d.setHours(h, m, 0, 0);
  return d.toISOString();
};
[
  {
    id: "p1",
    match: "Arsenal vs Chelsea",
    league: "Premier League",
    kickoff_wat: isoToday(19, 45),
    market: "BTTS_YES",
    market_plain: "Both teams to score",
    confidence: 79.3,
    tier: "banker",
    form_home: ["W", "W", "D", "W", "L", "W"],
    form_away: ["D", "W", "L", "L", "W", "D"],
    goals_profile: ["Arsenal scored in 7 of their last 8 home games."],
    risk_flag: null,
    model_verdict: "Strong attacking edge for both sides.",
    odds: 1.85,
    status: "live",
    result: null,
    user_backed: false,
    one_line_reason: "Arsenal score at home, Chelsea concede on the road."
  }
];
const api = {
  /** POST /auth/signup/ — returns the created user (no tokens). */
  async signup(body) {
    const { code, number } = splitWhatsapp(body.whatsapp ?? "");
    const payload = {
      username: body.username,
      email: body.email,
      password: body.password,
      whatsapp_country_code: code,
      whatsapp_number: number
    };
    const raw = await request(ENDPOINTS.signup, {
      method: "POST",
      body: JSON.stringify(payload)
    });
    return { user: mapUser(raw) };
  },
  /** POST /auth/login/ — returns access+refresh tokens and the user. */
  async login(identifier, password) {
    const raw = await request(
      ENDPOINTS.login,
      {
        method: "POST",
        body: JSON.stringify({ username: identifier, password })
      }
    );
    const user = mapUser(raw.user);
    session.setTokens(raw.access, raw.refresh);
    writeUser(user);
    return { success: true, token: raw.access, refresh_token: raw.refresh, user };
  },
  /** POST /auth/logout/ — blacklists the refresh token. */
  async logout() {
    const refresh = session.getRefresh();
    try {
      await request(ENDPOINTS.logout, {
        method: "POST",
        body: JSON.stringify(refresh ? { refresh } : {})
      });
    } catch {
    }
    session.clear();
    return { success: true };
  },
  /** GET /auth/me/ */
  async getMe() {
    const raw = await request(ENDPOINTS.me);
    const u = mapUser(raw);
    writeUser(u);
    return u;
  },
  /** PATCH /auth/me/ */
  async updateMe(patch) {
    const body = {};
    if (patch.name !== void 0) body.username = patch.name;
    if (patch.whatsapp !== void 0) {
      const { code, number } = splitWhatsapp(patch.whatsapp);
      body.whatsapp_country_code = code;
      body.whatsapp_number = number;
    }
    const raw = await request(ENDPOINTS.me, {
      method: "PATCH",
      body: JSON.stringify(body)
    });
    const u = mapUser(raw);
    writeUser(u);
    return u;
  },
  /** POST /api/auth/verify-email/ — body: { email, code } */
  async verifyEmail(email, code) {
    await request(ENDPOINTS.verifyEmail, {
      method: "POST",
      body: JSON.stringify({ email, code })
    });
    return { success: true };
  },
  /** POST /auth/resend-verification/ — body: { email } */
  async resendVerification(email) {
    await request(ENDPOINTS.resendVerification, {
      method: "POST",
      body: JSON.stringify({ email })
    });
    return { success: true };
  },
  /** POST /auth/forgot-password/ — body: { email } */
  async forgotPassword(email) {
    await request(ENDPOINTS.forgotPassword, {
      method: "POST",
      body: JSON.stringify({ email })
    });
    return { success: true };
  },
  /** POST /auth/reset-password/ — body: { token, user_id, new_password, confirm_password } */
  async resetPassword(token, password, user_id) {
    await request(ENDPOINTS.resetPassword, {
      method: "POST",
      body: JSON.stringify({
        token,
        user_id: user_id ?? "",
        new_password: password,
        confirm_password: password
      })
    });
    return { success: true };
  },
  /** POST /auth/change-password/ */
  async changePassword(old_password, new_password) {
    await request(ENDPOINTS.changePassword, {
      method: "POST",
      body: JSON.stringify({
        old_password,
        new_password,
        confirm_password: new_password
      })
    });
    return { success: true };
  },
  // ============== Picks API (with mock fallback) ====
  /** GET /algo/public/record/ — Public audited pick record */
  async getRecord(days = 90) {
    try {
      return await request(ENDPOINTS.algoPublicRecord, {
        search: { days: String(days) }
      });
    } catch {
      return {
        summary: { hit_rate: 66.3, roi_flat: 18.4, picks_logged: 358, wins: 237, losses: 95, voids: 26, pending: 0, window_days: 90 },
        picks: []
      };
    }
  },
  /** GET /algo/public/summary/ — Public summary for landing page */
  async getPublicSummary() {
    try {
      return await request(ENDPOINTS.algoPublicSummary);
    } catch {
      return { hit_rate: 66.3, roi_flat: 18.4, picks_logged: 358, wins: 237, losses: 95, voids: 26, pending: 0, window_days: 90 };
    }
  },
  /** GET /algo/picks/ — Daily picks (optional date) */
  async getTodayPicks(date) {
    try {
      return await request(ENDPOINTS.algoPicks, date ? { search: { date } } : {});
    } catch {
      return {
        date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
        published: true,
        run_id: 1,
        posted_at: (/* @__PURE__ */ new Date()).toISOString(),
        summary: { fixture_count: 4, market_count: 6, selected_pick_count: 3, picks_70_plus: 1, picks_65_plus: 2, markets_70_plus: 1, markets_65_plus: 2 },
        fixtures: []
      };
    }
  },
  /** GET /algo/top-pick/ — Top pick of the day */
  async getTopPick(date) {
    try {
      return await request(ENDPOINTS.algoTopPick, date ? { search: { date } } : {});
    } catch {
      return {
        date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
        published: true,
        pick: null
      };
    }
  },
  /** GET /algo/picks/:id/ — Get a specific pick */
  async getPick(id) {
    return request(ENDPOINTS.algoPick(id));
  },
  /** POST /algo/picks/:id/back/ — Mark that user backed this pick */
  async markBacked(id) {
    await request(ENDPOINTS.algoBackPick(id), { method: "POST" });
    return { success: true };
  }
};
const Ctx = createContext(null);
function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const refresh = async () => {
    if (!session.hasToken()) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const u = await api.getMe();
      setUser(u);
    } catch {
      session.clear();
      setUser(null);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void refresh();
    const onStorage = () => void refresh();
    if (typeof window !== "undefined") window.addEventListener("storage", onStorage);
    return () => {
      if (typeof window !== "undefined") window.removeEventListener("storage", onStorage);
    };
  }, []);
  const logout = async () => {
    await api.logout();
    setUser(null);
  };
  return /* @__PURE__ */ jsx(Ctx.Provider, { value: { user, loading, isAuthed: !!user, refresh, logout }, children });
}
function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside <AuthProvider>");
  return v;
}
dayjs.extend(utc);
dayjs.extend(timezone);
const TZ = "Africa/Lagos";
function formatKickoff(iso) {
  if (!iso) return "–";
  let parsed = dayjs(iso);
  if (!parsed.isValid() && typeof iso === "string") {
    const num = parseInt(iso, 10);
    if (!isNaN(num)) {
      parsed = dayjs(num);
    }
  }
  if (!parsed.isValid()) {
    return "–";
  }
  return parsed.tz(TZ).format("HH:mm") + " WAT";
}
function todayLagos() {
  return dayjs().tz(TZ).format("dddd D MMMM");
}
const logoFull = "/assets/betpreneur-logo-horizontal-D4uGfKw6.png";
const navItems = [
  { to: "/home", label: "Home", icon: Home },
  { to: "/top-pick", label: "Top Pick", icon: Trophy },
  { to: "/record", label: "Record", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings }
];
function AppShell({ children }) {
  const { isAuthed } = useAuth();
  const router2 = useRouter();
  const path = router2.state.location.pathname;
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen flex flex-col bg-background text-foreground", children: [
    /* @__PURE__ */ jsx("header", { className: "sticky top-0 z-20 bg-primary border-b border-primary", children: /* @__PURE__ */ jsxs("div", { className: `mx-auto h-20 flex items-center justify-between px-4 md:px-8 lg:px-12 xl:px-16 2xl:px-24 ${path === "/" ? "max-w-[1600px]" : path === "/home" ? "max-w-[1400px]" : "max-w-3xl"}`, children: [
      /* @__PURE__ */ jsx(
        Link,
        {
          to: "/",
          "aria-label": "Betpreneur — home",
          className: "flex items-center rounded-md transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-primary",
          children: /* @__PURE__ */ jsx(
            "img",
            {
              src: logoFull,
              alt: "Betpreneur",
              className: "h-10 md:h-11 w-auto select-none",
              draggable: false
            }
          )
        }
      ),
      /* @__PURE__ */ jsx("nav", { className: "hidden md:flex items-center gap-5 text-[14px]", children: isAuthed ? navItems.map((n) => /* @__PURE__ */ jsx(
        Link,
        {
          to: n.to,
          className: "text-white/80 hover:text-white transition-colors",
          activeProps: { className: "text-white font-semibold underline underline-offset-8 decoration-2" },
          children: n.label
        },
        n.to
      )) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Link, { to: "/record", className: "text-white/80 hover:text-white", activeProps: { className: "text-white font-semibold" }, children: "Record" }),
        /* @__PURE__ */ jsx(Link, { to: "/top-pick", className: "text-white/80 hover:text-white", activeProps: { className: "text-white font-semibold" }, children: "Top Pick" }),
        /* @__PURE__ */ jsx(
          Link,
          {
            to: "/login",
            className: "text-white/90 hover:text-white border border-white/40 hover:border-white px-4 py-2 rounded-md text-[13px] font-semibold uppercase tracking-wide",
            children: "Log in"
          }
        ),
        /* @__PURE__ */ jsx(
          Link,
          {
            to: "/signup",
            className: "bg-white text-primary px-4 py-2 rounded-md text-[13px] font-semibold hover:bg-white/90 uppercase tracking-wide",
            children: "Sign up"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsx("span", { className: "md:hidden text-[12px] text-white/80", children: todayLagos() })
    ] }) }),
    /* @__PURE__ */ jsx("main", { className: `flex-1 w-full pb-24 md:pb-10 pt-4 ${path === "/" ? "" : path === "/home" ? "max-w-[1400px] mx-auto px-3 md:px-6" : "mx-auto max-w-3xl px-4"}`, children }),
    isAuthed && /* @__PURE__ */ jsx("nav", { className: "md:hidden fixed bottom-0 inset-x-0 z-20 bg-[#0D0D0D] border-t border-brand-border", children: /* @__PURE__ */ jsx("ul", { className: "grid grid-cols-4", children: navItems.map((n) => {
      const active = path === n.to || n.to === "/home" && path.startsWith("/match");
      const Icon = n.icon;
      return /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
        Link,
        {
          to: n.to,
          className: `h-[56px] flex flex-col items-center justify-center gap-0.5 text-[11px] ${active ? "text-primary font-semibold" : "text-muted-foreground"}`,
          children: [
            /* @__PURE__ */ jsx(Icon, { className: "h-5 w-5" }),
            n.label
          ]
        }
      ) }, n.to);
    }) }) })
  ] });
}
const faviconUrl = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiI+CiAgPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iNiIgZmlsbD0iIzBEMEQwRCIvPgogIDx0ZXh0IHg9IjE2IiB5PSIyNCIgZm9udC1mYW1pbHk9IkFyaWFsIEJsYWNrLCBBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyMiIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IiNFRjQ0NDQiIHRleHQtYW5jaG9yPSJtaWRkbGUiPkI8L3RleHQ+Cjwvc3ZnPg0K";
const appCss = "/assets/styles-wCNGnbvN.css";
function NotFoundComponent() {
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
const Route$b = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Betpreneur — Daily football picks" },
      { name: "description", content: "Daily pre-match football picks with a documented 66.3% hit rate. Built for Nigerian punters." },
      { name: "author", content: "Project Betpreneur" },
      { property: "og:title", content: "Betpreneur — Daily football picks" },
      { property: "og:description", content: "Daily pre-match football picks with a documented 66.3% hit rate. Built for Nigerian punters." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:title", content: "Betpreneur — Daily football picks" },
      { name: "twitter:description", content: "Daily pre-match football picks with a documented 66.3% hit rate. Built for Nigerian punters." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/c1d819c8-b8ab-4a30-915b-d2b3b4139a7b/id-preview-879ff483--dd03e80d-9415-405e-983e-73f6a243c9d5.lovable.app-1777551394453.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/c1d819c8-b8ab-4a30-915b-d2b3b4139a7b/id-preview-879ff483--dd03e80d-9415-405e-983e-73f6a243c9d5.lovable.app-1777551394453.png" }
    ],
    links: [
      { rel: "icon", type: "image/png", href: faviconUrl },
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  return /* @__PURE__ */ jsx(AuthProvider, { children: /* @__PURE__ */ jsx(AppShell, { children: /* @__PURE__ */ jsx(Outlet, {}) }) });
}
const $$splitComponentImporter$a = () => import("./verify-email-BRQgXhla.js");
const Route$a = createFileRoute("/verify-email")({
  validateSearch: (s) => ({
    email: typeof s.email === "string" ? s.email : void 0
  }),
  head: () => ({
    meta: [{
      title: "Verify your email — Betpreneur"
    }, {
      name: "description",
      content: "Confirm your email to activate your Betpreneur account."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./top-pick-r0pAoL94.js");
const Route$9 = createFileRoute("/top-pick")({
  head: () => ({
    meta: [{
      title: "Today's top pick � Betpreneur"
    }, {
      name: "description",
      content: "The single highest-confidence football pick today."
    }, {
      property: "og:title",
      content: "Today's top pick � Betpreneur"
    }, {
      property: "og:description",
      content: "Highest-confidence pre-match pick. Subscribers see the full reasoning."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./signup-DdaPRR_d.js");
const Route$8 = createFileRoute("/signup")({
  head: () => ({
    meta: [{
      title: "Sign up — Betpreneur"
    }, {
      name: "description",
      content: "Create your free Betpreneur account and get daily audited football picks."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./settings-B0S3SYn3.js");
const Route$7 = createFileRoute("/settings")({
  head: () => ({
    meta: [{
      title: "Settings — Betpreneur"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./reset-password-DY2RzVNL.js");
const Route$6 = createFileRoute("/reset-password")({
  validateSearch: (s) => ({
    token: typeof s.token === "string" ? s.token : void 0,
    user_id: typeof s.user_id === "string" ? s.user_id : void 0
  }),
  head: () => ({
    meta: [{
      title: "Set a new password — Betpreneur"
    }, {
      name: "description",
      content: "Choose a new password for your Betpreneur account."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./record-DwYrEsM1.js");
const Route$5 = createFileRoute("/record")({
  head: () => ({
    meta: [{
      title: "Track record � Betpreneur"
    }, {
      name: "description",
      content: "All Betpreneur picks from the last 90 days. Auto-settled. Nothing deleted."
    }, {
      property: "og:title",
      content: "Betpreneur � 90-day track record"
    }, {
      property: "og:description",
      content: "66.3% hit rate. +18.4% ROI. 358 picks."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./login-C5tfVRZW.js");
const Route$4 = createFileRoute("/login")({
  head: () => ({
    meta: [{
      title: "Log in — Betpreneur"
    }, {
      name: "description",
      content: "Log in to your Betpreneur account."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./home-DPk9LNdX.js");
const Route$3 = createFileRoute("/home")({
  head: () => ({
    meta: [{
      title: "Dashboard — Betpreneur"
    }, {
      name: "description",
      content: "Full market scorecard — all games analysed today with confidence scores across every market."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./forgot-password-DKmaIwjt.js");
const Route$2 = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [{
      title: "Reset your password — Betpreneur"
    }, {
      name: "description",
      content: "Request a password reset link for your Betpreneur account."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./index-BrzsZ6WO.js");
const Route$1 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Betpreneur — Smarter football picks, every matchday"
    }, {
      name: "description",
      content: "Pre-match picks built on a transparent, audited model. 66%+ hit rate, +18% ROI, every pick logged before kick-off."
    }, {
      property: "og:title",
      content: "Betpreneur — Smarter football picks"
    }, {
      property: "og:description",
      content: "Audited 90-day record. Picks posted before kick-off. Nothing deleted."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./match._id-BIGYUw9h.js");
const Route = createFileRoute("/match/$id")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const VerifyEmailRoute = Route$a.update({
  id: "/verify-email",
  path: "/verify-email",
  getParentRoute: () => Route$b
});
const TopPickRoute = Route$9.update({
  id: "/top-pick",
  path: "/top-pick",
  getParentRoute: () => Route$b
});
const SignupRoute = Route$8.update({
  id: "/signup",
  path: "/signup",
  getParentRoute: () => Route$b
});
const SettingsRoute = Route$7.update({
  id: "/settings",
  path: "/settings",
  getParentRoute: () => Route$b
});
const ResetPasswordRoute = Route$6.update({
  id: "/reset-password",
  path: "/reset-password",
  getParentRoute: () => Route$b
});
const RecordRoute = Route$5.update({
  id: "/record",
  path: "/record",
  getParentRoute: () => Route$b
});
const LoginRoute = Route$4.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$b
});
const HomeRoute = Route$3.update({
  id: "/home",
  path: "/home",
  getParentRoute: () => Route$b
});
const ForgotPasswordRoute = Route$2.update({
  id: "/forgot-password",
  path: "/forgot-password",
  getParentRoute: () => Route$b
});
const IndexRoute = Route$1.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$b
});
const MatchIdRoute = Route.update({
  id: "/match/$id",
  path: "/match/$id",
  getParentRoute: () => Route$b
});
const rootRouteChildren = {
  IndexRoute,
  ForgotPasswordRoute,
  HomeRoute,
  LoginRoute,
  RecordRoute,
  ResetPasswordRoute,
  SettingsRoute,
  SignupRoute,
  TopPickRoute,
  VerifyEmailRoute,
  MatchIdRoute
};
const routeTree = Route$b._addFileChildren(rootRouteChildren)._addFileTypes();
function DefaultErrorComponent({ error, reset }) {
  const router2 = useRouter();
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("div", { className: "mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10", children: /* @__PURE__ */ jsx(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-8 w-8 text-destructive",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        strokeWidth: 2,
        children: /* @__PURE__ */ jsx(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
          }
        )
      }
    ) }),
    /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight text-foreground", children: "Something went wrong" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "An unexpected error occurred. Please try again." }),
    false,
    /* @__PURE__ */ jsxs("div", { className: "mt-6 flex items-center justify-center gap-3", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const getRouter = () => {
  const router2 = createRouter({
    routeTree,
    context: {},
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
    defaultErrorComponent: DefaultErrorComponent
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route$a as R,
  api as a,
  Route$6 as b,
  Route as c,
  formatKickoff as f,
  logoFull as l,
  router as r,
  todayLagos as t,
  useAuth as u
};
