function n(e){return null}export{n as S};
